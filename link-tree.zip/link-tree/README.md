# Link Tree

A lightweight, data-driven link-tree page. All content and theming is controlled through JSON files — no code changes needed to add links, swap colors, or update page text.

---

## How it works

The site is a single HTML page (`index.html`) that loads content at runtime from JSON files in the `links/` folder. There are no databases or build steps — just open the file in a browser (via a local web server) and it works.

### Loading sequence

1. `index.html` loads `styles/main.css` for layout and structure.
2. `scripts/populate-links.js` runs and reads the `?type=` parameter from the URL (e.g. `?type=education`).
3. It fetches `links/link_lookup.json` to find the matching entry.
4. From that entry it:
   - Generates and injects a color theme as a `<style>` block in the page head.
   - Sets the page title, subtitle, and footer text.
   - Fetches the appropriate link data file (e.g. `links/educational_links.json`).
   - Renders each link as a card on the page.

### URL parameter

| URL | Result |
|-----|--------|
| `index.html` | Loads the first entry in `link_lookup.json` |
| `index.html?type=education` | Loads the `education` entry |
| `index.html?type=entertainment` | Loads the `entertainment` entry |

---

## File structure

```
link-tree/
├── index.html                    # Page shell — no content lives here
├── README.md                     # This file
├── links/
│   ├── link_lookup.json          # Registry of all page configurations
│   ├── educational_links.json    # Link data for the education page
│   └── entertainment_links.json  # Link data for the entertainment page
├── scripts/
│   └── populate-links.js         # All runtime logic
└── styles/
    └── main.css                  # Layout and component styles
```

---

## Non-developer guide: customising the site through JSON

You do not need to touch any HTML, CSS, or JavaScript to change the site's content, colors, or text. Everything is controlled through the files in the `links/` folder.

### link_lookup.json — page configuration

This file is the main control panel. Each entry in the list represents one version of the page, selectable via the URL.

```json
[
    {
        "name": "education",
        "file": "educational_links.json",
        "theme": "indigo light",
        "page_title": "Educational Links",
        "page_subtitle": "A curated collection of learning resources",
        "page_footer": "These are some great resources!"
    }
]
```

#### Field reference

| Field | What it does | Example |
|-------|-------------|---------|
| `name` | The URL parameter that loads this page | `"education"` → `?type=education` |
| `file` | The JSON file containing the links to display | `"educational_links.json"` |
| `theme` | Color theme: a color name followed by `dark` or `light` | `"indigo light"`, `"red dark"` |
| `page_title` | Large heading shown at the top of the page | `"My Links"` |
| `page_subtitle` | Smaller italic text below the heading | `"Updated weekly"` |
| `page_footer` | Small text shown at the bottom of the page | `"Contact me at..."` |

> **Tip:** Set `page_title`, `page_subtitle`, or `page_footer` to `""` (empty quotes) to hide that section entirely.

#### Available theme colors

Use any of these color names followed by `dark` or `light`:

`red` · `orange` · `amber` · `yellow` · `lime` · `green` · `teal` · `cyan` · `sky` · `blue` · `indigo` · `violet` · `purple` · `pink` · `rose`

**Examples:** `"blue dark"`, `"orange light"`, `"rose dark"`, `"teal light"`

---

### Link data files (e.g. educational_links.json)

Each file contains a list of cards to display on the page. There are two types of card.

#### Type 1 — Link card (opens a website)

```json
{
    "title": "Wikipedia",
    "content": "https://www.wikipedia.org",
    "type": "url",
    "icon": "📖"
}
```

| Field | What it does |
|-------|-------------|
| `title` | The text shown on the card |
| `content` | The full URL the card links to (must start with `https://`) |
| `type` | Must be `"url"` for a link card |
| `icon` | An emoji or image URL shown to the left of the title |

#### Type 2 — Text card (expandable information)

```json
{
    "title": "About this page",
    "content": "This page contains a curated list of links.",
    "type": "text",
    "icon": "ℹ️"
}
```

| Field | What it does |
|-------|-------------|
| `title` | The text shown on the card (always visible) |
| `content` | The text revealed when the card is clicked |
| `type` | Must be `"text"` for an expandable card |
| `icon` | An emoji shown to the left of the title |

#### Adding a new link

1. Open the relevant JSON file (e.g. `educational_links.json`).
2. Copy an existing entry.
3. Paste it inside the `[...]` list, making sure each entry is separated by a comma.
4. Update the `title`, `content`, and `icon` fields.
5. Save the file.

#### Adding a new page entirely

1. Create a new link data file in `links/` (e.g. `my_links.json`) following the format above.
2. Add a new entry to `link_lookup.json` pointing to that file.
3. Access it at `index.html?type=<name>`.

---

## Running locally

The page uses `fetch()` to load JSON files, which requires a web server — opening `index.html` directly as a file will not work. The simplest option is the VS Code **Live Server** extension: right-click `index.html` and choose "Open with Live Server".
